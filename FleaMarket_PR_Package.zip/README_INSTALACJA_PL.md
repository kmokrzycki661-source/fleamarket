# Dom Towarowy (Flea Market) — paczka do przeniesienia (wersja UI V2/V4)

Nazwa widoczna dla gracza to **"Dom Towarowy"** (tytuł okna, opcja u NPC, komunikaty o
ograniczeniu do M1). Nazwy w kodzie (klasy, komendy `/flea_*`, nazwy plików) zostały celowo
bez zmian — to kosmetyczna zmiana etykiety, nie przemianowanie całej funkcji.

Ta paczka zawiera **źródła**, nie gotowy binarny plik `game`. Jest przygotowana dla serwera
opartego na tym samym systemie **Ikarus Offline Shop** (`ENABLE_IKASHOP_RENEWAL`) oraz
PlayerBotach. Nie należy jej wgrywać na czysty, standardowy serwer Metin2 ani bez porównania
nadpisywać plików.

To jest **nowsza wersja** wcześniejszej paczki (`FleaMarket_dla_znajomego`) — to okno zostało
od tamtej pory całkowicie przepisane (`customfleamarket.py`, kategorie po lewej, filtry po
stronie serwera, streaming ofert partiami). Jeśli admin ma już starą paczkę wgraną, tę należy
traktować jako pełny upgrade, nie dodatek.

## Co robi

- globalny katalog ofert (graczy + botów) dostępny u Handlarki Różności (NPC 9003) w M1;
- lewy panel kategorii: Broń (z podkategoriami), Zbroje, Helmy, Tarcze, Buty, Bransolety,
  Naszyjniki, Kolczyki, Księgi, Księgi zapomnienia, Kamienie duszy, Rudy i przetopy, Dopalacze,
  Używalne, Ulepszacze (materiały do ulepszania + rybie ości + małż), Inne (w tym kostiumy —
  ta zakładka nie ma już własnej kategorii);
- kilka przedmiotów bez własnego typu w silniku (dzielą typ z dziesiątkami niezwiązanych
  przedmiotów) jest przypisanych do kategorii po numerze `vnum`, nie po typie — patrz
  `CATEGORY_VNUM_OVERRIDES`/`CATEGORY_VNUM_RANGE_OVERRIDES` w `customfleamarket.py`;
- wyszukiwarka tekstowa z podpowiedziami nazw (również nazw Ksiąg Umiejętności — księga
  przechowuje konkretną umiejętność w sockecie 0, więc wyszukiwanie po nazwie umiejętności
  też trafia w księgę);
- filtr ceny od/do i 5 trybów sortowania (cena rosnąco/malejąco, cena za sztukę, nazwa A-Z,
  sprzedawca A-Z);
- kupowanie zdalne (bez odwiedzania sklepu) — dystans do sklepu nie jest sprawdzany tylko
  dla zakupów z tego okna, cała reszta walidacji (flood-check, cena, ekwipunek, złoto) jest
  taka sama jak przy zwykłym kupnie;
- kupowanie części stosu — osobne okienko z suwakiem ilości (`FleaMarketQuantityDialog`,
  wciąż żyje w `offlineshopsearch.py`), cena przeliczana identycznie jak po stronie serwera
  (zaokrąglenie w górę o 1 Yang);
- podpowiedź sugerowanej ceny przy wystawianiu własnego przedmiotu w zwykłym sklepie
  (na podstawie cen botów i historii sprzedaży graczy);
- zwykły sklep NPC nadal otwiera się przez opcję **„Kup przedmioty”** — Flea Market to
  dodatkowa opcja obok, nie zamiennik.

## Architektura (żeby scalanie miało sens)

Cała funkcja stoi na tym samym mechanizmie co reszta komend gracza: klient wysyła
`net.SendChatPacket("/flea_...")`, serwer odbiera to zwykłym `ACMD` z tabeli komend, a
odpowiedzi idą z powrotem przez `ch->ChatPacket(CHAT_TYPE_COMMAND, "Flea... ...")`, które
`game.py` rozsyła dalej po stronie klienta. Żadnych nowych typów pakietów.

Katalog ofert **nie ma własnej tabeli w bazie** — to czysta agregacja w pamięci nad istniejącą
mapą sklepów Ikarus Offline Shop (`m_mapShops`). Warunek konieczny: serwer docelowy musi mieć
już działający `ENABLE_IKASHOP_RENEWAL` z własnymi tabelami `ikashop_*`.

Nie ma osobnego procesu/wątku ("pompy") do wysyłki ofert — jest to zwykły powtarzający się
`event_create` na gracza (`func_flea_market_stream`), wysyłający paczki po 100 ofert co ok.
0,5 sekundy, żeby nie zalać połączenia starszego klienta.

## Zawartość paczki

- `client_root/` — pełne, aktualne pliki roota klienta zawierające integrację. **To są duże,
  wspólne pliki z mnóstwem innych, niezwiązanych mechanik z tego serwera** (customowe okna,
  boty, itp.) — scalaj tylko oznaczone fragmenty, nie nadpisuj całych plików.
- `server_src/` — analogicznie, pełne pliki źródłowe serwera z integracją rynku.
- `quest/flea_market.quest` — dialog Handlarki Różności (NPC 9003), self-contained, można
  skopiować w całości.

### Dokładna mapa zmian (szukaj po tych markerach/liniach)

Numery linii odnoszą się do plików w tej paczce (mogą się przesunąć względem innej wersji
bazowej — traktuj je jako punkt startowy do wyszukania markerów `flea`/`Flea`/`FLEA`).

**Klient (`client_root/`):**

| Plik | Co jest flea-market | Gdzie |
|---|---|---|
| `customfleamarket.py` | Cały plik — nowe okno. Zależy od `offlineshopsearch.FleaMarketQuantityDialog` i natywnego modułu `ikashop`. | całość |
| `offlineshopsearch.py` | Tylko klasa `FleaMarketQuantityDialog` (okienko "kup część stacka") + 3 linie na końcu pliku (`import customfleamarket` + rebind `FleaMarketWindow`). Reszta pliku to stary, niezwiązany kod wyszukiwarki oferty NPC/graczy. | klasa `FleaMarketQuantityDialog`, koniec pliku |
| `offlineshopmanage.py` | Podpowiedź ceny przy wystawianiu przedmiotu: `self.fleaPriceDialog`/`self.fleaPriceRequestID` (2 pola w `__init__`), `__SetFleaMarketPriceHint`, `__RequestFleaMarketPrice`, `SetFleaMarketPriceQuote`, oraz jedno wywołanie `self.__RequestFleaMarketPrice(...)` na końcu metody otwierającej okno dialogowe ceny. | linie ~182-183, ~486-533, wywołanie ~572 |
| `interfacemodule.py` | Konstrukcja okna (`self.fleaMarket = offlineShopSearch.FleaMarketWindow()` + 2 linie `SetToolTip`/`SetGuestBoard`), sprzątanie w `Destroy()`/`del`, metoda `OpenFleaMarket()`. | ~8 linii łącznie, szukaj `fleaMarket` |
| `game.py` | 3 wpisy w tabeli komend (`FleaMarketOpen`, `FleaPriceQuote`, `FleaMarketStackUpdate`) + 3 metody (`OpenFleaMarket`, `FleaPriceQuote`, `FleaMarketStackUpdate`), wszystkie tylko przekazują dalej do `interfacemodule`. | ~10 linii łącznie |
| `uiikashop.py` | Bez zmian flea-specific — dołączony tylko jako odniesienie/zależność (natywny moduł `ikashop`, z którego Flea Market korzysta). Prawdopodobnie już masz swoją wersję — **nie kopiuj, jeśli Twoja działa**. | — |

**Serwer (`server_src/`):**

| Plik | Co jest flea-market | Gdzie |
|---|---|---|
| `cmd.cpp` | 4 deklaracje `ACMD(do_flea_...)` + 4 wiersze w tabeli komend (`flea_buy`, `flea_query`, `flea_filter` pod `#ifdef ENABLE_IKASHOP_RENEWAL`; `flea_price` poza tym ifdefem — to celowe, bo podpowiedź ceny działa też bez rynku). | linie ~301-305, ~716-720 |
| `cmd_gm.cpp` | Jedna funkcja `ACMD(do_flea_price)`. | linie ~4405-4426 |
| `ikarus_shop_manager.cpp` | **Największy blok.** Nowe samodzielne kawałki: `IsFleaMarketMap()` (~85-99), streaming ofert `func_flea_market_stream` + jego stan (~428-483), globalny stan filtra/zapytania/zdalnego-kupna (~2721-2737), trzy komendy `do_flea_buy`/`do_flea_query`/`do_flea_filter` (~5049-5163). **Modyfikacje w istniejących funkcjach** (uważaj przy scalaniu — to punktowe zmiany w środku dużych, natywnych funkcji): `RecvShopBuyItemClientPacket` (dodano ominięcie sprawdzania dystansu dla zdalnego zakupu, ~2758-2760 i ~2774, plus ograniczenie do całych stosów ~2800-2801) oraz `RecvShopSearchFillRequestClientPacket` (dodano filtrowanie po zapytaniu/umiejętności/kategorii/cenie i limit 6000 ofert, ~3824-3982). | patrz wyżej |
| `playerbot_manager.h` / `.cpp` | Jedna metoda `SendFleaMarketPriceQuote()` — korzysta z istniejących, już obecnych w projekcie funkcji ekonomii botów (`GetPlayerBotShopAskingPrice`, `GetPlayerBotSaleUnitPrice`, `GetPlayerBotSkillBookSkillVnum`); nie wymaga `ENABLE_IKASHOP_RENEWAL`. | `.h` linia ~50, `.cpp` linie ~6299-6323 |
| `cmd_general.cpp` | **Brak** — poprzednia paczka wymieniała ten plik, ale w aktualnej wersji nic z Flea Market tam nie ma. Możesz go pominąć. | — |

## Instalacja — krótko

1. Zrób kopię swojego `root`, źródeł serwera i bazy danych.
2. Sprawdź, czy docelowy serwer ma działający Ikarus Offline Shop (`ENABLE_IKASHOP_RENEWAL`)
   i PlayerBoty. Bez nich ta wersja nie jest kompatybilna.
3. W folderze źródeł serwera **porównaj i ręcznie scal** pliki z `server_src` z ich
   odpowiednikami, trzymając się mapy zmian powyżej. Nie nadpisuj w ciemno.
4. Skopiuj `quest/flea_market.quest` do folderu questów i skompiluj quest standardową
   metodą używaną na docelowym serwerze.
5. Przebuduj binarkę `game` z jego źródeł, a następnie zrestartuj serwer.
6. Rozpakuj docelowy klientowy `root`, scal pliki z `client_root` wg mapy zmian powyżej,
   spakuj root docelowym packerem i podmień wynikowy pakiet klienta.
7. Uruchom klienta od nowa i przetestuj:
   - zwykły sklep NPC nadal działa przez „Kup przedmioty”;
   - otwarcie Flea Marketu w M1 (opcja „Flea Market” u Handlarki Różności);
   - Flea Market **poza** M1 pokazuje komunikat i się nie otwiera;
   - wyszukiwanie po nazwie, w tym po nazwie umiejętności dla Ksiąg;
   - filtr kategorii/ceny i wszystkie 5 trybów sortowania;
   - zakup jednej sztuki i zakup części stosu (suwak ilości);
   - podpowiedź ceny przy wystawianiu własnego przedmiotu w sklepie NPC.

## Ważne

- Paczka nie zawiera bazy danych — Ikarus Offline Shop musi mieć już własne tabele `ikashop_*`.
- Paczka nie zawiera binarki `game` — jest zależna od wersji źródeł, bibliotek i systemu
  docelowego serwera.
- Aktualna wersja wysyła oferty partiami po 100 co około 0,5 s (`FLEA_MARKET_STREAM_BATCH_SIZE`,
  `GetFleaMarketStreamInterval()` w `ikarus_shop_manager.cpp`). To bezpieczny wariant dla
  starszego klienta; dalsze przyspieszanie trzeba testować na docelowym serwerze.
- Twardy limit katalogu: 6000 najtańszych ofert na raz (`FLEA_MARKET_MAX_LISTINGS`) — reszta
  jest odcinana, żeby nie zalać połączenia przy bardzo dużym świecie.
- Jeśli NPC Handlarki Różności ma inny vnum niż `9003`, zmień go w `quest/flea_market.quest`.
- Flea Market jest twardo ograniczony do map o indeksie `1`, `21`, `41` (`IsFleaMarketMap` w
  `ikarus_shop_manager.cpp` i ten sam warunek w `quest/flea_market.quest`) — jeśli M1 na
  docelowym serwerze ma inny indeks mapy, zmień w obu miejscach.
