# Flea Market: globalny, przeszukiwalny rynek ofert (M1)

## Skrót

Dodaje "Flea Market" — okno dostępne u Handlarki Różności (NPC 9003) w M1, które agreguje
**wszystkie aktywne oferty** sklepów offline (graczy i botów) w jeden przeszukiwalny,
filtrowalny, sortowalny katalog, z możliwością kupna zdalnego (bez odwiedzania sklepu) i
kupna częściowego stosu. Zwykły sklep NPC działa bez zmian — to dodatkowa opcja obok.

Zbudowane w całości na już istniejącym systemie **Ikarus Offline Shop**
(`ENABLE_IKASHOP_RENEWAL`): nie wprowadza nowej tabeli w bazie, nowego typu pakietu ani
nowego procesu. Katalog to agregacja w pamięci nad istniejącą mapą sklepów; komunikacja to
zwykłe komendy tekstowe (`ACMD` + `ChatPacket`) tego samego rodzaju co reszta komend gracza.

## Dlaczego

Native Offline Shop wymaga fizycznego odwiedzenia każdego sklepu, żeby zobaczyć ofertę — na
serwerze z wieloma botami-sprzedawcami i graczami prowadzącymi sklepy to szybko robi się
nieporęczne: nie ma jak sprawdzić "kto sprzedaje X i za ile" bez biegania po mapie. Flea
Market rozwiązuje to jednym miejscem, w którym gracz wpisuje nazwę przedmiotu (lub wybiera
kategorię) i widzi wszystkie pasujące oferty od razu, posortowane wg ceny.

## Co widzi gracz

- **Lewy panel kategorii** — Broń (z podkategoriami: miecze 1h/2h, łuki, sztylety, dzwony,
  wachlarze), Zbroje (zbroja/hełm/tarcza/buty/bransoleta/naszyjnik/kolczyk), Pasy, Pierścienie,
  Kostiumy, Księgi, Kamienie, Używalne, Materiały, Inne.
- **Wyszukiwarka tekstowa** z podpowiedziami nazw w locie (debounce 0.7s), w tym wyszukiwanie
  Ksiąg Umiejętności po nazwie konkretnej umiejętności (księga trzyma umiejętność w sockecie 0,
  więc np. wpisanie nazwy skilla trafia we właściwą księgę, nie tylko w ogólną nazwę "Księga").
- **Filtr ceny** (od/do) i **5 trybów sortowania**: cena rosnąco/malejąco, cena za sztukę,
  nazwa A-Z, sprzedawca A-Z.
- **Zakup zdalny jedną sztuką** (dialog potwierdzenia) i **zakup części stosu** (suwak ilości,
  cena przeliczana identycznie jak po stronie serwera — zaokrąglenie w górę o 1 Yang za
  częściowy zakup).
- Katalog dochodzi partiami (streaming), więc pierwsze wyniki są widoczne natychmiast nawet
  przy tysiącach ofert w świecie; twardy limit 6000 najtańszych ofert chroni przed zalaniem
  połączenia na bardzo dużym świecie.
- Przy wystawianiu własnego przedmiotu w zwykłym sklepie NPC gracz dostaje **podpowiedź
  sugerowanej ceny** na podstawie tego, za ile boty i inni gracze sprzedają ten sam przedmiot.

## Jak to działa (dla recenzenta)

- Klient → serwer: zwykłe `net.SendChatPacket("/flea_query ...")`,
  `"/flea_filter ..."`, `"/flea_buy ..."`, `"/flea_price ..."`, obsługiwane przez standardowe
  `ACMD` z tabeli komend (`cmd.cpp`).
- Serwer → klient: `ch->ChatPacket(CHAT_TYPE_COMMAND, "FleaMarketOpen"/"FleaPriceQuote"/...)`,
  odbierane przez istniejący dispatcher komend w `game.py` (`serverCommandList`), tak samo
  jak każda inna komenda serwer→klient w tym projekcie.
- Katalog ofert budowany jest w `RecvShopSearchFillRequestClientPacket` (rozszerzona istniejąca
  funkcja natywnego Offline Shopu): iteruje po żywej mapie sklepów, filtruje wg zapytania,
  umiejętności (dla Ksiąg), kategorii i ceny, sortuje, ucina do 6000 pozycji i wysyła partiami
  po 100 co ~0.5s przez powtarzający się `event_create` (`func_flea_market_stream`) — nie ma
  osobnego wątku/procesu.
- Zakup zdalny to rozszerzenie istniejącej `RecvShopBuyItemClientPacket`: flaga
  `g_fleaRemoteBuy` (ustawiana tylko na czas jednego wywołania przez `do_flea_buy`) omija
  wyłącznie sprawdzenie dystansu do sklepu — cała reszta walidacji (flood-check, stan zajętości,
  tryb edycji sklepu, cena widziana przez klienta vs aktualna, miejsce w ekwipunku, złoto)
  zostaje bez zmian. Zakup zdalny jest ograniczony do całych stosów (częściowy zakup zdalny nie
  jest okablowany przez odpowiedź bazy danych — okno z suwakiem ilości działa tylko lokalnie
  przy zwykłym zakupie w sklepie, na co dzień to i tak główny scenariusz).
- Wszystko ograniczone do M1 po stronie serwera (`IsFleaMarketMap`, indeksy map `1/21/41`) —
  ograniczenie sprawdzane niezależnie w quest NPC i w każdej komendzie `/flea_*`, więc obejście
  question dialogu questa nie omija zabezpieczenia.

## Zależności

- `ENABLE_IKASHOP_RENEWAL` (Ikarus Offline Shop) musi być włączone i mieć swoje tabele
  `ikashop_*` już działające.
- System PlayerBot — podpowiedź ceny (`SendFleaMarketPriceQuote`) korzysta z istniejących
  funkcji ekonomii botów (`GetPlayerBotShopAskingPrice`, `GetPlayerBotSaleUnitPrice`) do
  oszacowania sugerowanej ceny; bez botów funkcja nadal działa, ale podpowiedź będzie oparta
  tylko na cenach z historii sprzedaży graczy (mniej danych).

## Ograniczenia / rzeczy do wiedzy

- Brak własnej tabeli w bazie — to celowe (nic do migracji, nic do utraty przy błędzie w
  schemacie), ale też oznacza, że katalog znika i buduje się na nowo przy każdym zapytaniu;
  nie ma trwałej historii ofert poza tym, co już trzyma Offline Shop.
- Limit 6000 ofert jest twardy i ucina najdroższe pozycje ponad limit — przy bardzo dużym,
  zapełnionym świecie warto to mieć na uwadze przy planowaniu skali.
- Zakup zdalny częściowego stosu nie jest wspierany (patrz wyżej) — to świadomy kompromis, nie
  przeoczenie.

## Historia tej gałęzi

Poprzednia iteracja tego okna (pełne przeszukiwanie po stronie klienta, prostsza siatka
slotów) została w całości zastąpiona bieżącym, filtrowanym-po-stronie-serwera oknem
(`customfleamarket.py`). Martwy kod starej wersji (`FleaMarketRow` + stary
`FleaMarketWindow` w `offlineshopsearch.py`, ~730 linii) został usunięty przy okazji tego PR-a
— zostawiona jest tylko wciąż żywa `FleaMarketQuantityDialog` (okienko zakupu części stosu).
Usunięto też dwie zapomniane linie `sys_log(..., "FLEA_DEBUG ...")` z wczesnego etapu pracy
nad filtrowaniem.
